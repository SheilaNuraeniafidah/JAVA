/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bmi;

/**
 *
 * @author user
 */
public class BMI {

    public static void main(String[] args) {
        
    }
}
