/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.desaingui;

/**
 *
 * @author user
 */
public class DesainGui {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
